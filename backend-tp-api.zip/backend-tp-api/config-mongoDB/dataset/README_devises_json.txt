in mongoDB , devises have .id = "USD" or "EUR" (static/specified , no generated)
in rest-api and core, devises have .code="USD" or "EUR" instead of .id 