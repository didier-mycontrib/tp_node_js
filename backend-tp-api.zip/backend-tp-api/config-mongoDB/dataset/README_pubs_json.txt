in mongoDB , pubs (publications) have auto generated ._id 
in rest-api and core, (publication) have same ._id