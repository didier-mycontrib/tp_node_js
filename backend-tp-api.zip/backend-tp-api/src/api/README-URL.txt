/xyz-api/public/xyz (some GET)

/xyz-api/private/role_zzz/xyz (post, put, delete , some GET)