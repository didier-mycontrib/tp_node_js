import { Request, Response ,NextFunction, Router} from 'express';
import { Devise } from '../model/devise';
//import { ErrorWithStatus , NotFoundError, ConflictError } from '../error/errorWithStatus';
import { asyncToResp} from './apiHandler';
import { MemDeviseService } from '../core/mem/MemDeviseDataService';
import { DeviseDataService } from '../core/itf/deviseDataService';
import { MongoDeviseService } from '../core/mongo/MongoDeviseDataService';
import { NedbDeviseService } from '../core/nedb/NedbDeviseDataService';
import { MyAppConfig } from '../config/MyAppConfig';

export const deviseApiRouter = Router();

var  deviseService : DeviseDataService  = initDeviseService()
function initDeviseService() : DeviseDataService {
    if(MyAppConfig.isNoDB())
         //return new MemDeviseService();
         return new NedbDeviseService();
    else
        //return new NedbDeviseService();
        return new MongoDeviseService();
}

// .../devise-api/public/devise/EUR ou ...
deviseApiRouter.route('/devise-api/public/devise/:code')
.get(asyncToResp(async function(req :Request, res :Response , next: NextFunction){
    let codeDevise = req.params.code;
    let devise = await deviseService.findById(codeDevise)
    return devise;
}));

// http://localhost:8282/devise-api/publicdevise renvoyant tout [ {} , {}]
// http://localhost:8282/devise-api/public/devise?changeMini=1.1 renvoyant [{}] selon critere
deviseApiRouter.route('/devise-api/public/devise')
.get(asyncToResp(async function(req :Request, res :Response , next: NextFunction ) {
    let  changeMini = req.query.changeMini;
    let deviseArray = await deviseService.findAll();
    if(changeMini){
            //filtrage selon critère changeMini:
            deviseArray = deviseArray.filter((dev)=>dev.change >= changeMini);
        }
    return deviseArray;
}));

// .../devise-api/public/convert?source=EUR&target=USD&amount=100 renvoyant { ... } 
deviseApiRouter.route('/devise-api/public/convert')
.get(asyncToResp(async function(req :Request, res :Response , next: NextFunction){
    const  codeSrc = req.query.source;
    const  codeTarget = req.query.target;
    const  amount = Number(req.query.amount);
    const deviseSrc = await deviseService.findById(codeSrc);
    const deviseTarget = await deviseService.findById(codeTarget)
    return { source : codeSrc,
             target : codeTarget,
             amount : amount,
             result : amount * deviseTarget.change / deviseSrc.change
    };
}));


//POST ... with body { "code": "M1" , "name" : "monnaie1" , "change" : 1.123 }
deviseApiRouter.route('/devise-api/private/role_admin/devise')
.post(asyncToResp(async function(req :Request, res :Response , next: NextFunction ) {
    let  devise :Devise =  req.body ; //as javascript object via jsonParser
    let savedDevise = await deviseService.insert(devise);
                      // await deviseService.saveOrUpdate(devise);
    return savedDevise;
}));

//PUT ... with body { "code": "USD" , "nom" : "dollar" , "change" : 1.1 }
deviseApiRouter.route('/devise-api/private/role_admin/devise')
.put(asyncToResp(async  function(req :Request, res :Response , next: NextFunction ) {
    let  devise :Devise =  req.body ; //as javascript object
    let updatedDevise = await deviseService.update(devise);
    return updatedDevise;
}));

// DELETE http://localhost:8282/devise-api/private/role_admin/devise/EUR
deviseApiRouter.route('/devise-api/private/role_admin/devise/:code')
.delete(asyncToResp(async  function(req :Request, res :Response , next: NextFunction ) {
    let codeDevise = req.params.code;
    await deviseService.deleteById(codeDevise)
    return{ "action" : "devise with code="+codeDevise + " was deleted"};
}));




